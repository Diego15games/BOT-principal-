import {
  SlashCommandBuilder,
  MessageFlags
} from 'discord.js';

import { pegarConfig } from '../../systems/registro.js';
import {
  isTicketChannel,
  podeFecharTicket,
  MSG_SEM_PERMISSAO_FECHAR
} from '../../systems/tickets.js';
import { fecharTicket } from '../../systems/fecharTicket.js';

export default {
  data: new SlashCommandBuilder()
    .setName('fechar-ticket')
    .setDescription('Fechar ticket (apenas o staff que assumiu)'),

  async execute(interaction) {
    if (!isTicketChannel(interaction.channel)) {
      return interaction.reply({
        content: '❌ Este comando só pode ser usado dentro de um ticket.',
        flags: MessageFlags.Ephemeral
      });
    }

    if (!(await podeFecharTicket(interaction.member, interaction.channel))) {
      return interaction.reply({
        content: MSG_SEM_PERMISSAO_FECHAR,
        flags: MessageFlags.Ephemeral
      });
    }

    const config = (await pegarConfig()) || {};

    return fecharTicket(interaction, config, '🔒 Fechando ticket...');
  }
};
