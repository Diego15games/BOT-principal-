import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';

import { salvarConfig } from '../../systems/registro.js';

export default {
  data: new SlashCommandBuilder()
    .setName('ticket-config')
    .setDescription('Configurar tickets')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addRoleOption(option =>
      option
        .setName('staff')
        .setDescription('Cargo staff')
        .setRequired(false)
    )
    .addChannelOption(option =>
      option
        .setName('logs')
        .setDescription('Canal logs')
        .setRequired(false)
    )
    .addChannelOption(option =>
      option
        .setName('categoria')
        .setDescription('Categoria tickets')
        .setRequired(false)
    ),

  async execute(interaction) {
    const staff = interaction.options.getRole('staff');
    const logs = interaction.options.getChannel('logs');
    const categoria = interaction.options.getChannel('categoria');

    // Só grava o que foi informado (antes zerava os campos omitidos)
    // e usa as MESMAS chaves que o sistema de tickets lê (Mongo).
    const dados = {};

    if (staff) dados.ticketStaff = staff.id;
    if (logs) dados.ticketLogs = logs.id;
    if (categoria) dados.ticketCategoria = categoria.id;

    if (!Object.keys(dados).length) {
      return interaction.reply({
        content: '❌ Informe pelo menos uma opção para configurar.',
        flags: MessageFlags.Ephemeral
      });
    }

    await salvarConfig(dados);

    return interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x57f287)
          .setDescription('✅ Configuração salva.')
      ],
      flags: MessageFlags.Ephemeral
    });
  }
};
