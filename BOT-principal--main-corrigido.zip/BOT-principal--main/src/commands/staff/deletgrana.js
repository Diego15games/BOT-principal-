import {
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  MessageFlags
} from 'discord.js';

import {
  removeMoney,
  getMoney
} from '../../systems/economia.js';

export default {
  data: new SlashCommandBuilder()
    .setName('deletgrana')
    .setDescription('Retirar dinheiro de um jogador')
    .addUserOption(option =>
      option
        .setName('usuario')
        .setDescription('Jogador')
        .setRequired(true)
    )
    .addIntegerOption(option =>
      option
        .setName('valor')
        .setDescription('Valor a retirar')
        .setMinValue(1)
        .setRequired(true)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  cooldown: 3,

  async execute(interaction) {
    const usuario = interaction.options.getUser('usuario');
    const valor = interaction.options.getInteger('valor');

    if (valor <= 0) {
      return interaction.reply({
        content: '❌ Valor inválido.',
        flags: MessageFlags.Ephemeral
      });
    }

    const saldo = await getMoney(usuario.id);

    if (saldo <= 0) {
      return interaction.reply({
        content: '❌ Este jogador não possui dinheiro.',
        flags: MessageFlags.Ephemeral
      });
    }

    const novoSaldo = await removeMoney(usuario.id, valor);

    // Valor realmente retirado (se pediu mais do que o jogador tinha,
    // retira só o que existia).
    const retirado = Math.min(valor, saldo);

    const aviso =
      retirado < valor
        ? `\n\n⚠ O jogador tinha menos que o pedido, então foram retirados apenas **R$ ${retirado.toLocaleString('pt-BR')}**.`
        : '';

    try {
      await usuario.send({
        embeds: [
          new EmbedBuilder()
            .setColor(0xed4245)
            .setTitle('💸 Dinheiro Removido')
            .setDescription(
              `A staff removeu **R$ ${retirado.toLocaleString('pt-BR')}** da sua conta.\n\n` +
              `Seu novo saldo é **R$ ${novoSaldo.toLocaleString('pt-BR')}**.`
            )
        ]
      });
    } catch {}

    return interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0xed4245)
          .setTitle('💸 Dinheiro Removido')
          .setDescription(
            `✅ Foram removidos **R$ ${retirado.toLocaleString('pt-BR')}** de ${usuario}.\n\n` +
            `Novo saldo: **R$ ${novoSaldo.toLocaleString('pt-BR')}**${aviso}`
          )
      ],
      flags: MessageFlags.Ephemeral
    });
  }
};
