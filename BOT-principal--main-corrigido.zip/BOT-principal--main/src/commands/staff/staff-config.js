import {
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
  MessageFlags
} from 'discord.js';

import { salvarConfig } from '../../systems/registro.js';

export default {
  data: new SlashCommandBuilder()
    .setName('staff-config')
    .setDescription('Configurar cargo da staff')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addRoleOption(option =>
      option
        .setName('cargo')
        .setDescription('Cargo da equipe')
        .setRequired(true)
    ),

  cooldown: 3,

  async execute(interaction) {
    const cargo = interaction.options.getRole('cargo');

    // O cargo da staff usado pelo sistema de tickets fica no Mongo
    // (antes era salvo num JSON que nenhum código lia).
    await salvarConfig({ ticketStaff: cargo.id });

    return interaction.reply({
      embeds: [
        new EmbedBuilder()
          .setColor(0x57f287)
          .setDescription(`✅ Cargo staff configurado para ${cargo}`)
      ],
      flags: MessageFlags.Ephemeral
    });
  }
};
